import './App.css';
import Story from './Story';

function App(props) {
  return (
    <>
       <Story name='Julia'/>
    </>
  );
}

export default App;
